const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.get("/impressum", (req, res) => {
        res.render("impressum", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}