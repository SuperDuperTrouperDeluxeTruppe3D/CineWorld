const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.post("/payment", (req, res) => {
        res.render("payment", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}