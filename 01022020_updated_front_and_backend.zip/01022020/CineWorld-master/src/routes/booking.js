'use strict';
const constant = require("../constants/constants");
const model = require("../models/model");
const controller = require('../controllers/Controller.js');
const chosenFilm = require('./films');

module.exports.routes = (app) => {

    app.get("/booking", (req, res) => {
        //console.log(chosenFilm.chosenFilm);
        res.render("booking", {
            title: "Le Mans 66",
            saal: "1",
            spielZeit: "120",
            isTaken: constant.initialRating.isTaken,
            maxSeat: "22",
            maxRow: "22"
        });
        //controller.booking.findBooking(req, res);
    })

        .post("/booking", (req, res) => {
            controller.booking.bookFilm(req, res);
            /*const array = req.body.myArray;
            const parsed = JSON.parse(req.body.myArray || '{}');
            console.log(array);
            try {
                for (let i = 1; i < parsed.length; i++) {
                    if (typeof parsed[i] !== "undefined") {
                        model.Booking.update({_id: "5e027a4343633e5edc741006"}, {$set: {row: parsed[i].seat}}, function (err) {
                            if (err) {
                                console.log("err", err);
                            }
                        });
                        console.log(parsed[i].seat);
                        console.log(parsed[i].row);
                        console.log(parsed[i].adult);
                    }
                }
            } catch (err) {
                console.log("error from here");
            }*/



        })
        .delete("/booking", (req, res) => {
            controller.booking.cancelBooking(req, res);
        })


}