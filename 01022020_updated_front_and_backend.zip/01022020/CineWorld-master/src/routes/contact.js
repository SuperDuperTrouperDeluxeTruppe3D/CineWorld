const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.get("/contact", (req, res) => {
        res.render("contact", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}