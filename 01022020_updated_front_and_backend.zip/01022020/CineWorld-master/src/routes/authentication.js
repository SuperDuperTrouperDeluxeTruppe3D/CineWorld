const controller = require('../controllers/Controller.js');
const model = require('../models/model.js');

module.exports.routes = (app) => {

    app.get("/login", (req, res) => res.render("login"))

        .post("/login", (req, res) => {
           controller.user.login(req, res);
        })
        .get("/logout", (req, res)=>{
            console.log("before logout");
            req.logout();
            console.log("after logout");
            res.redirect("/");
        })
        .get('/signup', (req, res) =>{
            res.render('signup')
        })
        .get("/register", (req, res) => res.render("register"))

        .post("/register", (req, res) => {
           // controller.user.addNewUser(req, res);
            controller.user.createUser(req, res)
        })
}


