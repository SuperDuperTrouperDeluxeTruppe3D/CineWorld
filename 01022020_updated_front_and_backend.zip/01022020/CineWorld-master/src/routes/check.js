const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.get("/check", (req, res) => {
        res.render("check", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}