const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.post("/CashReservation", (req, res) => {
        res.render("CashReservation", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}