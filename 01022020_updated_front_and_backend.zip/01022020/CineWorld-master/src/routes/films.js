const multer = require("multer");
const constant = require("../constants/constants");
const controller = require('../controllers/Controller.js');
const model = require('../models/model.js');
let chosenFilm;
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads'); // null->when error
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);  // new Date().toISOString() +  in windows does not work with date
    }
});

const fileFilter = (req, file, cb) => {
    if (file.mimeType === "image/jpeg" || file.mimeType === "image/png") {
        cb(null, true); //accept
    } else {
        cb(null, false);  // reject a file
    }
};

const upload = multer(
    {
        storage: storage,
        limits: {
            fileSize: 1024 * 1024 * 5
        }
        //   ,  fileFilter: fileFilter // does not work
    });

module.exports.routes = (app) => {

    app.get('/films', (req, res) => {
         controller.film.preview(req, res);
    })
        .get('/films/:filmId', (req, res) => {
            chosenFilm= req.params.filmId;
            controller.film.renderFilmInfos(req, res);
        })

        .post("/films", upload.single("filmImage"), (req, res) => {
             controller.film.addFilm(req, res);
        })

        .post('/films/:filmId', (req, res) => {

        })

        .patch('/films/:filmId', (req, res) => {
            controller.film.update(req, res);
        })

        .delete('/films/:filmId', (req, res) => {
            controller.film.deleteFilm(req, res);
        })
        .get("/films/:filmId/booking/:bookId", (req, res)=>{
            //console.log(req.params)
    });
}


