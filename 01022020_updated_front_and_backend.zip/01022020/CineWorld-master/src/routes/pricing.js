const constant = require('../constants/constants.js');
module.exports.routes = (app) => {

    app.get("/pricing", (req, res) => {
        res.render("pricing", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

}