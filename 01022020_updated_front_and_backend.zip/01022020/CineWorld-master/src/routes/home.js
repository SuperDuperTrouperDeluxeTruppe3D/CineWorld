const constant = require('../constants/constants.js');
const paypal = require("paypal-rest-sdk");
const {payment} = require('../controllers/Controller.js');
module.exports.routes = (app) => {
    paypal.configure({
        'mode': 'sandbox', //sandbox or live
        'client_id': 'AcriMC4sfpa8lp6hu9-hVzGfslrywuCwDYQi-inJeDoK_E51YtOOpRHx0CX9HNrpu_OcKSrQVYplbEuA',
        'client_secret': 'EPA_Gmn7E3XCe-V7_z1Qs29EdqZDahZ9rb7AaMyQalFBP9RIbvs5KY4IKITNIzfOqMTAy5kIp7cAVD5G'
    });

    app.get("/", (req, res) => {
        res.render("home", {
            initialRating: constant.initialRating.Rating,
            initialAutohr: constant.initialRating.author
        })
    })

        .get("/searchBar", (req, res) => {
            res.render("searchBar");
        })

        .get("/pay", (req, res) => {
            res.render("pay");
        })

        .post('/pay', (req, res) => {
            const price= 3.00;
            const total = 3.00;
            payment.createPayment(req, res);

        })
        .get("/success", (req, res) => {
            const payerId = req.query.PayerID;
            const paymentId = req.query.paymentId;

            const execute_payment_json = {
                "payer_id": payerId,
                "transactions": [{
                    "amount": {
                        "currency": "USD",
                        "total": "1.00"
                    }
                }]
            };

            paypal.payment.execute(paymentId, execute_payment_json, function (error, payment) {
                if (error) {
                    console.log(error.response);
                    throw error;
                } else {
                    console.log(JSON.stringify(payment));
                    res.send("success");
                }
            });
        })
        .get("/cancel", (req, res) => res.send("canceled"))

    .get("/checkout", (req, res) =>{
        res.render("checkout")

    })
    ;
}

