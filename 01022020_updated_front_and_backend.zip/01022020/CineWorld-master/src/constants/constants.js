
exports.initialRating = {
    author: "mark",
    Rating: "Lacus vel facilisis volutpat est velit egestas dui id ornare. Semper auctor neque vitae tempus quam. Sit amet cursus sit amet" +
        "dictum sit amet justo. Viverra tellus in hac habitasse. Imperdiet proin fermentum leo vel orci porta. " +
        "Donec ultrices tincidunt arcu non sodales neque sodales ut. Mattis molestie a iaculis at erat" +
        " pellentesque adipiscing. Magnis dis parturient montes nascetur ridiculus mus mauris vitae ultricies." +
        "Adipiscing elit ut aliquam purus sit amet luctus venenatis lectus. Ultrices vitae auctor eu augue ut lectus arcu bibendum at." +
        "Odio euismod lacinia at quis risus sed vulputate odio ut. Cursus mattis molestie a iaculis at erat pellentesque adipiscing.",

    isTaken:[
        {
            r:3,
            s:5
        },
        {
            r:3,
            s:4
        }
    ],

    movies:[
        {
            id:"1",
            title:"Le Mans 66 - Gegen jede Chance",
            genre:"Drama, Porträt/Biographie, Sport",
            foto:"film1"
        },
        {
            id:"2",
            title:"Jumangie",
            genre:"",
            foto:"film2"
        },
        {
            id:"3",
            title:"Die Eiskönigin II",
            genre:"Animation",
            foto:"film3"
        }
    ]
};