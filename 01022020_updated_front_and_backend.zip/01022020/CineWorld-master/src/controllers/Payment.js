const paypal = require("paypal-rest-sdk");

paypal.configure({
    'mode': 'sandbox', //sandbox or live
    'client_id': 'AcriMC4sfpa8lp6hu9-hVzGfslrywuCwDYQi-inJeDoK_E51YtOOpRHx0CX9HNrpu_OcKSrQVYplbEuA',
    'client_secret': 'EPA_Gmn7E3XCe-V7_z1Qs29EdqZDahZ9rb7AaMyQalFBP9RIbvs5KY4IKITNIzfOqMTAy5kIp7cAVD5G'
});


class Payment {

    constructor() {
        this.paypalConfigure();
    }

    paypalConfigure() {
        paypal.configure({
            'mode': 'sandbox', //sandbox or live
            'client_id': 'AcriMC4sfpa8lp6hu9-hVzGfslrywuCwDYQi-inJeDoK_E51YtOOpRHx0CX9HNrpu_OcKSrQVYplbEuA',
            'client_secret': 'EPA_Gmn7E3XCe-V7_z1Qs29EdqZDahZ9rb7AaMyQalFBP9RIbvs5KY4IKITNIzfOqMTAy5kIp7cAVD5G'
        });
    }


    createPayment(req, res) {


        const price = 3.00;
        const total = 3.00;
        const create_payment_json = {

            "intent": "sale",
            "redirect_urls": {
                "return_url": "http://localhost:3000/check",
                "cancel_url": "http://localhost:3000/noCheck"
            },
            "payer": {
                "payment_method": "paypal"
            },
            "transactions": [
                {
                    "amount": {
                        "total": total,//"3.00",
                        "currency": "USD"
                    },
                    "description": "This is the payment transaction description.",
                },
            ]






            /* "intent": "sale",
             "payer":  {
                 "payment_method": "paypal"
             },
             "redirect_urls": {
                 "return_url": "http://localhost:3000/success",
                 "cancel_url": "http://localhost:3000/cancel"
             },
             "transactions": [{
                 "item_list": {
                     "items": [{
                         "name": "item",
                         "sku": "item",
                         "price": "1.00",
                         "currency": "USD",
                         "quantity": 1
                     }]
                 },
                 "amount": {
                     "currency": "USD",
                     "total": "1.00"
                 },
                 "description": "This is the payment description."
             }]*/
        };
        paypal.payment.create(create_payment_json, function (error, payment) {
            if (error) {
                console.log(" the error from here");
                throw error;
            } else {
                for (let i = 0; i < payment.links.length; i++) {
                    if (payment.links[i].rel === 'approval_url') {
                        res.redirect(payment.links[i].href)

                    }
                }
            }
        });
    }


}

exports.Payment = Payment;
/*

module.exports = (req, res) => {

    const price = 3.00;
    const total = 3.00;
    const create_payment_json = {

        "intent": "sale",
        "redirect_urls": {
            "return_url": "http://localhost:3000/success",
            "cancel_url": "http://localhost:3000/cancel"
        },
        "payer": {
            "payment_method": "paypal"
        },
        "transactions": [
            {
                "amount": {
                    "total": total,//"3.00",
                    "currency": "USD"
                },
                "description": "This is the payment transaction description.",
            },
        ]






        /!* "intent": "sale",
         "payer":  {
             "payment_method": "paypal"
         },
         "redirect_urls": {
             "return_url": "http://localhost:3000/success",
             "cancel_url": "http://localhost:3000/cancel"
         },
         "transactions": [{
             "item_list": {
                 "items": [{
                     "name": "item",
                     "sku": "item",
                     "price": "1.00",
                     "currency": "USD",
                     "quantity": 1
                 }]
             },
             "amount": {
                 "currency": "USD",
                 "total": "1.00"
             },
             "description": "This is the payment description."
         }]*!/
    };

    paypal.payment.create(create_payment_json, function (error, payment) {
        if (error) {
            console.log(" the error from here");
            throw error;
        } else {
            for (let i = 0; i < payment.links.length; i++) {
                if (payment.links[i].rel === 'approval_url') {
                    res.redirect(payment.links[i].href)

                }
            }
        }
    });


}*/
