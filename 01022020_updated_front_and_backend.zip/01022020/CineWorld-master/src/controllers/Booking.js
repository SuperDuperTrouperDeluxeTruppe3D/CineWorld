//jshint esversion:6
//'use strict';
const _ = require("lodash");
const model = require('../models/model.js');
const controller = require('./Controller.js');
const {transformEvent, transformBooking} = require('./merge');

class Booking {

    async findBooking(req, res) { // Booking
        /*if (!req.isAuth) {
            throw new Error("Unauthenticated");
        }*/
        if (req.isAuthenticated()){
            try {
                const bookings = await model.Booking.find()
                    .populate("user film")
                const response = {
                    count: bookings.length,
                    booking: bookings.map(booking => {
                        return transformBooking(booking);
                    })
                }
                return res.status(200).json({response});
            } catch (err) {
                throw err;
            }
        } else{
            res.render("/login");
        }
    }

    async bookFilm(req, res) {  // bookevent postman

        if (!req.isAuthenticated()) {
            res.render("/login");
            
        }
        const username = req.user.username;
        const customer = await model.User.findOne({username:username});
        const filmId ="5e046b6e1c9d440000aa8335";
        const fetchEvent = await model.Film.findOne({_id:filmId});  // req.body.filmId
        const booking = new model.Booking({
            user: customer._id, // req.userId
            film: fetchEvent
        });
        //let bookingInfos;
        const result = await booking.save();
        const response = transformBooking(result);
        res.status(200).json(response);
       // res.status(200).render("dummyPage");


        /*  .then(user => {
              if (!user) {
                  throw new Error("User does not exist");
              }
              user.bookedFimls.push(filmTitle);
              return user.save();
          })
          .then(results => {

              return {...bookingInfos._doc, _id: bookingInfos.id};
          })
          .catch(err => console.log("error from created booking"));*/
    }

    async cancelBooking(req, res) {
        if (!req.isAuthenticated()) {
            throw new Error("Unauthenticated");
        }
        try {
            const booking = await model.Booking.findById(req.body.bookingId).populate("film");
            const event = transformEvent(booking.film);
            await model.Booking.deleteOne({_id: req.body.bookingId});
            res.status(200).json(event);
        } catch (err) {
            throw err
        }
    }
}

exports.Booking = Booking;
