//jshint esversion:6
'use strict';
const _ = require("lodash");
const mongoose = require("mongoose");
const model = require('../models/model.js');
const {transformEvent } = require('./merge');


/**
 * film class
 * all methods works, navigate very slow
 */

class Film {

    async findFilmEvents(req, res) { // postman2, events, await, transformEvent
        try {
            const events = await model.Film.find()
                .populate("user")
           const response = events.map(film => {
                return transformEvent(film)
            });
            res.status(200).json(response);
        } catch (err) {
            throw err;
        }
    }

     preview (req, res) { // postman2, events, await, transformEvent
            const preview =  model.Preview.find({}, (err, filmPreview)=>{
                res.render("films", {
                    movies: filmPreview
                });
            }
        );
    }


   async addFilm(req, res) {  //postman2 // createEvent
        if (!req.isAuth){
            throw new Error("Unauthenticated!");
        }
        const film = new model.Film({
            _id: mongoose.Types.ObjectId(),
            title: req.body.title,
            description: req.body.description,
            price: req.price,
            playingTime: req.body.playingTime,
            date: req.body.date,
            photo: req.body.photo,
            user: req.userId //"5e00e055da84e96e7cc8e742"
        });
        let addedFilm;
        try {
            const result = await film.save();
            addedFilm = transformEvent(result);
           /* addedFilm = {
                ...result._doc,
                _id: result.id,
               // date: dateToString(result._doc.date),
                user: fc_user.bind(this, result._doc.user)
            };*/
            const user = await model.User.findById(req.userId); // "5e00e055da84e96e7cc8e742"
            if (!user) {
                throw new Error("User  not found")
            }
            user.bookedFimls.push(film);
            user.save();
            res.status(200).json({
                ...result._doc,
                _id: result.id
            });
            return addedFilm;
        }catch(err){
            console.log(err);
            throw err;
        }

    }

   async  renderFilmInfos(req, res) {
        //const requestedFilm = req.params.filmId;

       const dateObj = new Date();
       const month = dateObj.getUTCMonth() + 1; //months from 1-12
       const day = dateObj.getUTCDate();
       const year = dateObj.getUTCFullYear();
       const newDate = year + "/" + month + "/" + day;

       try {
           const Films = await model.Film.findById("5e046b6e1c9d440000aa8335");
           res.status(200).render("filmItem", { title: Films.title,
               genre: Films.genre,
               fsk: Films.fsk,
               laenge: Films.laenge,
               crew: Films.crew,
               start: Films.start,
               spielwoche: Films.playingTime,
               short: Films.short,
               long: Films.long,
               foto: Films.photo,
               heute: newDate,                  //"SO, 15.12",
               morgen: "MO, 16.12",
               uebermorgen:"DI, 17.12"
           });

       } catch(err){
           console.log(err);
       }




    }

    // postman
    findFilmById(req, res) {
        const id = req.params.filmId;
        const film = model.Film.findById(id)
            .select("_id title description playingtime price date photo user")
            .then(foundFilm => {
                if (foundFilm) {
                    res.status(200).json({
                        films: foundFilm._doc,
                        url: {
                            type: "GET",
                            url: "http://localhost:3000/films/" + foundFilm.id
                        }
                    });
                } else {
                    res.status(404).json({message: "No valid entry was found"});
                }
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({Error: err})
            });
        //  return film;
    }

    findfilms(req, res) { // postman events
        return model.Film.find()
            .select("_id title description playingtime price date photo user")
            .exec()
            .then(foundFilms => {
                const response = {
                    count: foundFilms.length,
                    films: foundFilms.map(film => {
                        return {
                            ...film._doc,
                            _id: film.id,
                            request: {
                                type: "GET",
                                url: "http://localhost:3000/films/" + film.id
                            }
                        };
                    })
                };
                res.status(200).json({response});
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({Error: err})
            });
    }

    addAFilm(req, res) {  //works postman
        const film = new model.Film({
            _id: new mongoose.Types.ObjectId(),
            title: req.body.title,
            description: req.body.description,
            price: req.body.price,
            playingTime: req.body.playingTime,
            date: req.body.date,
            photo: req.file.path,
            user: "5dfce3fb1c9d440000e89fb3"
        });
        film.save()
            .then(result => {
                if (!result) {
                    return res.status(404).json({
                        message: "Film not found"
                    });
                }
                res.status(200).json({
                    message: "Successfully added a new Film",
                    film: {
                        ...result._doc,
                        request: {
                            type: "GET",
                            url: "http://localhost:3000/films/" + result.id
                        }
                    }
                });
                return result;
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({Error: err})
            });

    }

    deleteFilm(req, res) {
        const id = req.params.filmId;
        const deletedFilm = model.Film.deleteOne({_id: id})
            .exec()
            .then(result => {
                res.status(200).json({
                    message: "successfully deleted the product",
                    request: {
                        type: "POST",
                        url: "http://localhost:3000/films",
                        body: {title: "String", price: "Number"}
                    }
                });
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({Error: err});
            });
    }

    update(req, res) { // not working-> body is not array// vid5
        const id = req.params.filmId;
        const updateOps = {};
        for (const ops of req.body) {
            updateOps[ops.propName] = ops.value;
        }
        model.Film.update({_id: id}, {$set: updateOps})
            .exec()
            .then(result => {
                console.log(result);
                res.status(500).json({
                    message: "film updated",
                    request: {
                        type: "GET",
                        url: "http://localhost:3000/films/" + id
                    }
                });
            })
            .catch(err => {
                console.log(err);
                res.status(500).json({Error: err});
            });
    }


}

exports.Film = Film;


