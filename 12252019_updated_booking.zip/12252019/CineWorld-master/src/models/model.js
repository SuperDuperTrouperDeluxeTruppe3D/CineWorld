const mongoose = require('mongoose');

const Schema = mongoose.Schema;

userSchema = new Schema({
    email:  {
        type: String,
        required: true,
       // unique: true
    },
    password:  {
        type: String,
       required: true
    },
    bookedFimls: [
        {
            type: Schema.Types.ObjectID, // all ids of films that user booked
            ref: "Film"
        }
    ]
});


//film schema
filmSchema = new Schema({
    filmId: String,
    title: {
        type: String,
        required: true
    },
    description: String,
    playingTime: String,
    price: {
        type: Number,
        required: true
    },
    date :{
        type: String,
        Date, Date
       // required: true
    },
    photo: {
        type: String,
        //required: true
    }
    ,
    user: [{
        type: Schema.Types.ObjectID,
        ref: "User"
    }]
});


ratingSchema = new Schema({
    author: String,
    content: String
});


bookingSchema = new Schema({
    film: {
        type: Schema.Types.ObjectID,
        ref: "Film"
    },
    user: {
        type: Schema.Types.ObjectID,
        ref: "User"
    }
} /*,{ timestamp: true }*/);


exports.User = new mongoose.model("User", userSchema);
exports.Film = new mongoose.model("Film", filmSchema);
exports.Rating = new mongoose.model("Rating", ratingSchema);
exports.Booking = mongoose.model("Booking", bookingSchema);

