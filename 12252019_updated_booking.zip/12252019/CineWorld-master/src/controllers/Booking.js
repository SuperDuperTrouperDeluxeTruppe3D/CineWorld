//jshint esversion:6
'use strict';
const _ = require("lodash");
const model = require('../models/model.js');
const users = require('./User.js');
const films = require('./Film.js');

const User = users.User;
const Film = films.Film;


class Booking {


    findBooking() {

        const bookings = model.Booking.find({}, (err, foundBookings) => {
            if (err) {
                console.log(err)
            } else {
                console.log(foundBookings)
                return foundBookings;
            }
        });
        return bookings;
    }

    createBooking(username, filmTitle) {

        const customer = new User();
        //const film = new Film();
        const booking = new model.Booking({
            user: username,
            film: filmTitle
        });
        let bookingInfos;
        return booking.save()
            .then(results => {
                bookingInfos = {...results._doc};
                return model.User.findById(username);
                //return customer.findUserById(username)
            })
            .then(user => {
                if (!user) {
                    throw new Error("User does not exist");
                }
                user.bookedFimls.push(filmTitle);
                return user.save();
            })
            .then(results => {
                return bookingInfos;
            })
            .catch(err => console.log(err));
    }
}

module.exports = {
    Booking: Booking
};
