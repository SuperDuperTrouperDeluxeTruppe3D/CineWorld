//jshint esversion:6
'use strict';

const users = require('./User.js');
const films = require('./Film.js');
const bookings = require('./Booking.js');

const User = users.User;
const Film = films.Film;
const Booking = bookings.Booking;

const user = new User();
const film = new Film();
const booking = new Booking();

// test code
//"5df4e978010626653cb252fa"
//console.log(film.findFilm("harry potter"));
//console.log(foundFilm);
// username "1@44.com"
// userId ObjectId("5df3995aa6770532c4feab80")
//console.log(user.findUserById("5df649a3450502c3ccd657e9"));
//console.log(user.findUser());
 const booking1 = booking.createBooking("5df64d9b1a8c5cd84cf5ca9b" ,"5df606a9d63db571505b3c1c" );
console.log( booking1);






module.exports = {
    user    : user,
    film    : film,
    booking : booking

};


//module.exports.User = new User();


