//jshint esversion:6
'use strict';
const _ = require("lodash");
const model = require('../models/model.js');

const film = {
    filmId: "122",
    title: "Harry",
    description: "new film",
    playingTime: "one hour",
    price: 234,
    date: "onehour",
    photo: 1224
};

/**
 * film class
 * all methods works, navigate very slow
 */

class Film {


    findFilmById(filmId) {

        const film = model.Film.findById({_id: filmId})
            .then(foundFilm => {
                return foundFilm;
            })
            .catch(err => {
                console.log(err);
            })
        return film;
    }

    findFilm(title) {

        console.log("type of arg is " + typeof title);
        if (arguments.length === 0) {
            // .find()
            // no args passed, return all usernames in an object
            const film = model.Film.find()
                .then(films => {
                    console.log(films);
                    return films;
                })
                .catch(err => {
                    throw err
                });
            return film;
        } else if (typeof title === "string") {

            const film = model.Film.find({title: title}).then(foundedFilm => {
                    //console.log(foundedFilm)
                    return {...foundedFilm._doc};
                }
            ).catch(err => {
                console.log(err);
            });
            return film
        } else {
            // unsupported arguments passed
            console.log("Unsupported");
        }
        return;
    }

    addFilm() {
        const newFilm = new model.Film({
            title: film.title,
            description: film.description,
            price: film.price,
            playingTime: film.playingTime,
            date: film.date,
            photo: film.photo,
            customer: "5df3995aa6770532c4feab80"
        });

        // let addedFilm;
        newFilm.save().then(results => {
            // console.log(results);
            return results;
        }).catch(err => {
            console.log(err);
        });


        /* .then(result => {
            // addedFilm = {...result.doc};
             return model.User.findById("5df3995aa6770532c4feab80")
             console.log(result);
         })
         .then(user => {
             if (!user){
                 throw new Error("User not found");
             }
            // user.addFilm().push(newFilm);
             console.log(newFilm);
             return user.save();
         })
          .then(result => {
            //  console.log(addedFilm);
             //return addedFilm;
         })
         .catch(err => {
             console.log(err);
             throw  err;
         });*/
    }

    navigateToFilm(req, res) {
        const requestedFilm = req.params.filmId;

        model.Film.findOne({filmId: requestedFilm}, (err, foundFilm) => {
            if (err) {
                console.log(err)
            }
            if (foundFilm) {
                res.render("films",
                    {
                        title: foundFilm.title,
                        description: foundFilm.description,
                        playingTime: foundFilm.playingTime,
                        photo: foundFilm.photo

                    });
            }
            // res.end();
        });
    }

}

module.exports = {
    Film: Film
};

