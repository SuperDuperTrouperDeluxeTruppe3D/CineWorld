//jshint esversion:6
require('dotenv').config();
const express = require("express");
const ejs = require("ejs");
const bodyParser = require("body-parser");
const mongoose = require('mongoose');
const routes = require('./src/routes/routes.js');
const PORT = 3000;
const app = express();

app.use(bodyParser.urlencoded({
    extended: true
}));
app.set('view engine', 'ejs');
app.use(express.static("public"));


mongoose.connect("mongodb://localhost:27017/kinoUserDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("MongoDB connected…")
})
    .then(() => {

        routes.routes(app);
    })
    .then(() => {
        app.listen(PORT, () => console.log("Server started on port 3000"));
    })
    .catch(err => console.log(err))


