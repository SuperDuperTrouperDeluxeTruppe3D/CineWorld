/*

//console.log(foundFilm);
/!*  const bookEvent =  async args => {
      const booking = new model.Booking({
          user: username,
          film: filmTitle
      });
          const results = await booking.save();

          return {
              ...results._doc
          };
  }*!/

/!* const booking = new model.Booking({
     user: username,
     film: filmTitle
 })
     .save()
     .then(createdBoooking => { return createdBoooking;
         /!*return {
             ...createdBoooking
             //user: model.User.bind(booking._doc.user),
             //film: model.Film.bind(booking._doc.film)
         };*!/
     })
     .catch(err => {
         console.log(err)
     });*!/





findUser(username) { // works, overloading ok

    console.log("type is" + typeof username);
    if (arguments.length === 0) {
        // .find()
        // no args passed, return all usernames in an object
        return model.User.find()
            .then(users => {
                return users;
                console.log(users);
                return users.map(user => {
                    return {...user._doc};
                });
            })
            .catch(err => {
                throw err
            });

    } else if (typeof username === "string") {

        model.User.find({email: username})
            .then(user => {
                console.log(user);
                return {...user._doc};
            }).catch(err => {
            console.log(err);
        })

    } else {
        // unsupported arguments passed
        console.log("Unsupported");
    }

}*/


/*

resultFactory(result) {

    if (Object.prototype.toString.call(result) === '[object Array]') {
        result.forEach((item, index) => {
            result[index] = new this(item);
        });
    }

    if (Object.prototype.toString.call(result) === '[object Object]') {
        if (result.hasOwnProperty('value') && !result.hasOwnProperty('_id')) {
            if (result.value) {
                result = new this(result.value);
            } else {
                result = undefined;
            }
        } else if (result.hasOwnProperty('ops')) {
            result.ops.forEach((item, index) => {

                result.ops[index] = new this(item);
            });

            result = result.ops;
        } else if (result.hasOwnProperty('_id')) {
            result = new this(result);
        }
    }
    return result;
}
*/
